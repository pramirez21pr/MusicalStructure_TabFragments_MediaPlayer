package com.example.android.tabfragments;

import android.support.design.widget.TabLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import android.widget.TextView;

import com.example.android.tabfragments.R;
import com.example.android.tabfragments.SectionsPageAdapter;
import com.example.android.tabfragments.Tab2Fragment;
import com.example.android.tabfragments.Tab3Fragment;

import android.content.Intent;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";

    private SectionsPageAdapter mSectionsPageAdapter;

    private ViewPager mViewPager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d(TAG, "onCreate: Starting.");

        mSectionsPageAdapter = new SectionsPageAdapter(getSupportFragmentManager());

        // Set up the ViewPager with the sections adapter.
        mViewPager = findViewById(R.id.container);
        setupViewPager(mViewPager);

        TabLayout tabLayout = findViewById(R.id.tabs);
        tabLayout.setupWithViewPager(mViewPager);
    }

    private void setupViewPager(ViewPager viewPager) {
        SectionsPageAdapter adapter = new SectionsPageAdapter(getSupportFragmentManager());
        adapter.addFragment(new Tab1Fragment(), "TAB 1");
        adapter.addFragment(new Tab2Fragment(), "TAB 2");
        adapter.addFragment(new Tab3Fragment(), "TAB 3");
        viewPager.setAdapter(adapter);
    }
    songList songs = new songList();
    final ArrayList<song> SongItems = songs.getSongList();
    RecyclerView recyclerView = findViewById(R.id.recycler_view);
    SongAdapter adapter = new SongAdapter(this, SongItems, new CustomClickListener() {
        @Override
        public void onItemClick(View v, int position) {
            song currentSong = SongItems.get(position);
            String artistName = currentSong.getArtistName();
            String artistSong = currentSong.getArtistSong();
            String artistFeatured = currentSong.getArtistFeatured();
            int artistImage = currentSong.getArtistImage();

            Intent nowPlayingIntent = new Intent(MainActivity.this, NowPlaying.class);
            nowPlayingIntent.putExtra("artist", artistName);
            nowPlayingIntent.putExtra("artistSong", artistSong);
            nowPlayingIntent.putExtra("artistFeat", artistFeatured);
            nowPlayingIntent.putExtra("artistImage", artistImage);
            startActivity(nowPlayingIntent);

            LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getBaseContext());
            recyclerView.setLayoutManager(linearLayoutManager);
            recyclerView.setAdapter(adapter);

        }

    });


}



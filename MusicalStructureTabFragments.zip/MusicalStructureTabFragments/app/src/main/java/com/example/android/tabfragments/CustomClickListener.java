package com.example.android.tabfragments;

import android.view.View;

public interface CustomClickListener {
    void onItemClick(View v, int position);
}
